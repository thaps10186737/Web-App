<html>
<header>
    <title>Index</title>
<style>
.feature{
    margin-top:20%;
    margin-left:39%;
    color:rgb(253,251,212)	;
    
}
.All{
margin-left:63.2%;
margin-top:-3%;
width:8%;
background-color:green;
} 
.background_img{

}

.backdrop{
background-image:url('img/logo_img');
background-position: center;
background-size: cover;
display:initial;
max-width: 2000px;
margin: 0 auto;
}
.f{
    margin-left:43%; 
    color:white;  
}
</style>



<body class="backdrop">


<div class="background_img">    
</div>

<div class="feature">

<h1  id="msg"><h1>



<script type="text/javascript">


setTimeout(welcome,1000);

function welcome(){
document.getElementById("msg").innerHTML="Welcome";
setTimeout(To,1000);
    }


function To(){
document.getElementById("msg").innerHTML="Welcome To"
setTimeout(Exclusive,1000);
}


function Exclusive(){
document.getElementById("msg").innerHTML="Welcome To Exclusive Colognes"
setTimeout(message,1000)
}


function message(){
document.getElementById("msg").innerHTML="Welcome To Exclusive Colognes"
setTimeout(slogan,1000);
}




</script>
</div>

<div class="f">
<h1  id="msg1"><h1>     
<script>
function slogan(){
document.getElementById("msg1").innerHTML="Brand of the people"
setTimeout(login,4000);
}

function login(){
window.location = src = "http://localhost/WIL%20Project/homepage.php";
}
</script>
</header>
</div>
</body>
</html>
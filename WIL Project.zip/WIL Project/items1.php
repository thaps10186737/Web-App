<?php
session_start();
include "connect.php";

// Initialize cart if not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$count=(int)0;


$id = $_GET['id'];

$query = "SELECT * FROM `all_colognes_tbl` WHERE item_id = $id";

$result = mysqli_query($connects, $query);


while($row = mysqli_fetch_array($result)){


$count++;
?>

<div class="imgContainer1" style="margin-top:6%; align-items:center; margin-left:40%;">
<img style="box-shadow:5px 5px 5px 5px; margin-left:10px;  width:200px; height:200px;" 
src="<?php echo $row['item_img']?>"/>

<h5 style="margin-left:10px"><?php echo $row['item_name']?></h5></a>
<h3 style="margin-left:80px;">R<?php echo $row['cost']?><h3>



<a href="assign.php?item_id=<?php echo $row['item_id']; ?>&item_name=<?php echo urlencode($row['item_name']); ?>&item_image=<?php echo urlencode($row['item_img']); ?>&item_price=<?php echo $row['cost']; ?>">
<button style="width:6rem; margin-left:45px; color:white; cursor: pointer; background-color:orange;">ADD</button>
</a>


</div>


<?php
}
?>